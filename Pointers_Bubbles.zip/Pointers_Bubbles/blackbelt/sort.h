#ifndef SORT_H_EXISTS
#define SORT_H_EXISTS


class sort{
	private:
		int *arr;
		int temp;
		int a;
		int b;
		int x;	
	public:
		void swap();
		void sorting();
		void printValues();
};

#endif
